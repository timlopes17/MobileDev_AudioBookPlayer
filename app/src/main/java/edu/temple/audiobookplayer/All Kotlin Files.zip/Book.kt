package edu.temple.audiobookplayer

data class Book(val title : String, val author : String)